document.getElementById("exp").innerHTML = "Hello Class";

// get output using tag name
document.getElementsByTagName("p")[0].innerHTML = "This is my Paragraph";

document.querySelector('#exp1').innerHTML = "Ashis"


console.log("Hello Javascript!");
console.log('10' + 50);

document.write("Hello JavaScript!");

alert(50 + 50);


// javascript variables
    
x = 5;

console.log(x);

