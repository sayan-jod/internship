print("hello")
x=0
print(type(x))