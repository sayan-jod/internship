from django.shortcuts import render, redirect
from .models import *

# Create your views here.

def receipes(request):
    receipes = Receipe.objects.all()
    return render(request, 'receipes.html', {'receipes': receipes})

def add_receipes(request):
    if request.method == 'POST':
        # Process the uploaded file and save it to the database.
        data = request.POST
        
        receipe_image = request.FILES.get('receipe_image')
        receipe_name = data.get('receipe_name')
        receipe_description = data.get('receipe_description')    
        
        Receipe.objects.create(
            receipe_name = receipe_name,
            receipe_description = receipe_description,
            receipe_image = receipe_image,
        )
        return redirect('/add_receipes/')
    
    queryset = Receipe.objects.all()
    context = {
       'receipes': queryset,
    }
    
    return render(request, 'add_receipes.html', context)


def update_receipe(request, id):
    queryset = Receipe.objects.get(id = id)

    if request.method == 'POST':
        data = request.POST
        image = request.FILES.get('receipe_image')
        name = data.get('receipe_name')
        description = data.get('receipe_description')    
        
        queryset.receipe_name = name
        queryset.receipe_description = description
        
        if image:
            queryset.receipe_image = image
        
        queryset.save()
        return redirect('/add_receipes/')
        
    
    context = {'receipes': queryset}
    return render(request, 'update_receipe.html', context)


def delete_receipe(request, id):
    receipe = Receipe.objects.get(id=id)
    receipe.delete()
    return redirect('/add_receipes/')