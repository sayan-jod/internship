def myfunction():
    print("Hello from a function")
myfunction()

def myfunction2(fname,lname):
    print(fname + " " + lname)

myfunction2("sayan")

def myfunction3(country="india"):
    print("I am from " + country)

myfunction3()