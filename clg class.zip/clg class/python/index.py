def show():
    print("this is index.py")
    