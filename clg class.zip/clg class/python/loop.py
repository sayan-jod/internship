fruits=['apple','banana','cherry']
for i in fruits:
    print(i)
for x in range(10):
    print(x)
else:
    print("Finally finished!")